# Third-party notices

## Pocket Slicer mobile build

This engine includes Pocket Slicer's bounded native G-code visualization patch.
It removes retained desktop preview data while retaining the slicing pipeline,
timing calculations, filament accounting, and native print-area checks.
The complete local patch and reproducible build recipe are in `scripts/engine/`
in the app source and in `PocketSlicer-custom-source/` inside
[`orcawasm-source.zip`](../source/orcawasm-source.zip). That archive also contains
the original OrcaWasm source. The exact full OrcaSlicer source revision and all
build instructions are linked from [`ENGINE-SOURCE.txt`](../source/ENGINE-SOURCE.txt).
Artifact and source hashes are recorded in [`PROVENANCE.json`](PROVENANCE.json).
The original upstream notices follow.

## one-slicer-api glue

`wasm/oneslicer/oneslicer-emscripten-glue.js` and
`wasm/oneslicer/oneslicer-conformance.mjs` are copied unmodified from the
one-slicer-api 0.7.0 release. The glue is linked into `slicer-mt.js`.

- License: Apache License 2.0
- Copyright: one-slicer-api contributors

## OrcaSlicer

This repository embeds a WebAssembly build of
[OrcaSlicer](https://github.com/SoftFever/OrcaSlicer).

- License: GNU Affero General Public License v3.0 (AGPL-3.0)
- Copyright: SoftFever and OrcaSlicer contributors
- Source version: https://github.com/SoftFever/OrcaSlicer/tree/v2.4.2
- Compatibility changes: [`patches/apply.py`](patches/apply.py)

Per AGPL-3.0 §13, the complete corresponding source for this modified build,
including the patches, is available in this repository.

## PrusaSlicer / libslic3r

OrcaSlicer is a fork of
[PrusaSlicer](https://github.com/prusa3d/PrusaSlicer), also licensed under
AGPL-3.0.

## OCCT (Open CASCADE Technology)

OCCT 7.8.1 is compiled into the engine for STEP import:
https://github.com/Open-Cascade-SAS/OCCT

- License: Open CASCADE Technology Public License (modified LGPL-2.1 with a
  static-linking exception)
- Copyright: Open Cascade SAS and OCCT contributors

## oneTBB

The engine links [oneTBB](https://github.com/uxlfoundation/oneTBB) v2021.13.2,
built from source for `wasm32-emscripten` with pthread support.

- License: Apache License 2.0
- Copyright: Intel Corporation and oneTBB contributors

## libnoise

libnoise is compiled into the engine for the FuzzySkin feature:
https://github.com/amitsharma/libnoise

- License: GNU Lesser General Public License v2.1 (LGPL-2.1)
- Copyright: Jason Bevins and libnoise contributors
