# Corresponding source for Pocket Slicer's customized engine

This package contains the unchanged tracked OrcaWasm source at
`60a09e04f1990be39c8f6f35dffef1a2c9e224c4` in `OrcaWasm-60a09e04/`, and the complete Pocket Slicer
headless-memory patch plus portable build recipe in `PocketSlicer-custom-source/scripts/engine/`.
All original upstream files, including LICENSE, NOTICE, workflows, patches,
bridge, API glue, tests, dependency versions, and build metadata, are retained.

The full OrcaSlicer source is a separate, much larger download. Obtain this exact
revision, not an arbitrary newer branch:

- Full OrcaSlicer source archive: https://github.com/OrcaSlicer/OrcaSlicer/archive/8500fcdccaa10b5099ac20d252af3a7c560046f1.zip
- OrcaSlicer source tree: https://github.com/OrcaSlicer/OrcaSlicer/tree/8500fcdccaa10b5099ac20d252af3a7c560046f1
- OrcaWasm source tree: https://github.com/Hiosdra/OrcaWasm/tree/60a09e04f1990be39c8f6f35dffef1a2c9e224c4

To rebuild on Linux, copy `OrcaWasm-60a09e04/` to a new build directory as its
`orcawasm/` subdirectory, then run:

```sh
bash PocketSlicer-custom-source/scripts/engine/build.sh /path/to/build-directory all
```

The build script fetches the exact OrcaSlicer commit if the nested `orca/` source
is absent. Alternatively extract the full Orca archive into that nested folder.
It obtains pinned Emsdk and installs Emscripten 3.1.74, applies the original
upstream compatibility patches followed by `apply_headless.py`, fetches/builds
the dependency sources specified by the original recipe, and compiles the engine.
Use a build directory containing only letters, digits, `/`, `_`, `.`, and `-`.

Read `PocketSlicer-custom-source/scripts/engine/README.md` for prerequisites, exact source
and toolchain revisions, separate build stages, outputs, and validation steps.
The macro `ORCA_WASM_HEADLESS_GCODE=1` must be applied globally to every main Orca
C++ translation unit. The customized engine omits retained desktop toolpath
visualization data while preserving the print pipeline and native bounds checks;
the patch does not change user print settings or emitted print commands by design.
Execution tests are required to confirm output equivalence for a rebuilt binary.

Original upstream instructions are retained at `OrcaWasm-60a09e04/README.md`,
`scripts/build-local-wsl.sh`, and `.github/workflows/build-wasm.yml` inside that
folder. Those original scripts alone do not apply Pocket Slicer's custom patch.
The browser worker adapter and application source are distributed separately in
`pocket-slicer-source.zip`. Exact binary hashes are in `engine/PROVENANCE.json`
beside the application. Preserve the upstream licenses and notices when
redistributing source or binaries.
